Kindly include the iitbhulogo.eps image file in the same folder as the latex file before compiling the latex file.
